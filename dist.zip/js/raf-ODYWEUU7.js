import{M as o}from"./bootstrap-C1SX6ENO.js";const e=i=>o?window.requestAnimationFrame(i):setTimeout(i,16),r=i=>o?window.cancelAnimationFrame(i):clearTimeout(i);export{r as c,e as r};
